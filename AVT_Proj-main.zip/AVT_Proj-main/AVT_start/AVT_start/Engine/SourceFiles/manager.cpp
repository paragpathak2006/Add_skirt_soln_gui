#include "../HeaderFiles/manager.h"

Manager* Manager::instance = 0;